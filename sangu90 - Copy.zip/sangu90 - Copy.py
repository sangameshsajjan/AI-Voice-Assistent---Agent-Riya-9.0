import tkinter as tk

from tkinter import ttk

import threading

import speech_recognition as sr

import pyttsx3

import webbrowser

import wikipedia

import json

import os

import subprocess

import time

from PIL import Image, ImageTk, ImageDraw, ImageFilter

from urllib.parse import quote as urlquote

--------------------- Configuration ---------------------

ASSISTANT_NAME = "Agent Riya 9.0"

WINDOW_TITLE = "AI Voice Assistant - Agent Riya 9.0"

INITIAL_GREETING = "Hi, How can i help you today?"

TASKS_FILE = "tasks.json"

LISTEN_TIMEOUT = 6  # seconds for phrase_time_limit

-------------------- Persistence --------------------

def load_tasks():

if os.path.exists(TASKS_FILE):

    try:

        with open(TASKS_FILE, "r", encoding="utf-8") as f:

            return json.load(f)

    except Exception:

        return []

return []

def save_tasks(tasks):

try:

    with open(TASKS_FILE, "w", encoding="utf-8") as f:

        json.dump(tasks, f, ensure_ascii=False, indent=2)

except Exception as e:

    print("Failed to save tasks:", e)

-------------------- Utilities --------------------

def hex_to_rgb(hexstr):

h = hexstr.lstrip('#')

return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

-------------------- Voice Engine --------------------

class VoiceEngine:

def _init_(self, on_result_callback):

    self.recognizer = sr.Recognizer()

    try:

        self.microphone = sr.Microphone()

    except Exception as e:

        print("Microphone initialization failed:", e)

        raise



    self.on_result = on_result_callback

    self._running = False

    self.listen_thread = None



    # Real fix: Stop listening completely while speaking

    self._is_speaking = False

    self._speak_lock = threading.Lock()



    # Initialize TTS

    self.tts = pyttsx3.init()

    try:

        self.tts.setProperty('rate', 150)

        self.tts.setProperty('volume', 1.0)

        voices = self.tts.getProperty('voices')

        for v in voices:

            if 'female' in v.name.lower() or 'zira' in v.name.lower():

                self.tts.setProperty('voice', v.id)

                break

    except Exception:

        pass



# ---------------------------------------------------

# Listening control

# ---------------------------------------------------

def start_listening(self):

    if self._running:

        return

    self._running = True

    self.listen_thread = threading.Thread(target=self._background_listen, daemon=True)

    self.listen_thread.start()



def stop_listening(self):

    self._running = False

    time.sleep(0.2)



# ---------------------------------------------------

# Speaking (block listening)

# ---------------------------------------------------

def speak(self, text):

    def _worker():

        with self._speak_lock:

            self._is_speaking = True



        # Stop mic

        self.stop_listening()



        # Speak

        try:

            self.tts.say(text)

            self.tts.runAndWait()

        except Exception as e:

            print("TTS error:", e)



        # Wait for lingering audio

        time.sleep(0.6)



        # Resume listening

        with self._speak_lock:

            self._is_speaking = False

        self.start_listening()



    threading.Thread(target=_worker, daemon=True).start()



# ---------------------------------------------------

# Background listening loop

# ---------------------------------------------------

def _background_listen(self):

    with self.microphone as source:

        try:

            self.recognizer.adjust_for_ambient_noise(source, duration=1)

        except:

            pass



    while self._running:

        # Do not listen while TTS is speaking

        if self._is_speaking:

            time.sleep(0.1)

            continue



        try:

            with self.microphone as source:

                audio = self.recognizer.listen(source, phrase_time_limit=LISTEN_TIMEOUT)



            # If speaking started during recognition

            if self._is_speaking:

                continue



            threading.Thread(target=self._recognize_audio, args=(audio,), daemon=True).start()



        except Exception:

            time.sleep(0.3)



# ---------------------------------------------------

# Convert audio to text

# ---------------------------------------------------

def _recognize_audio(self, audio):

    if self._is_speaking:

        return

    try:

        text = self.recognizer.recognize_google(audio)

        self.on_result(text)

    except sr.UnknownValueError:

        pass

    except sr.RequestError:

        pass

-------------------- Main Application --------------------

class AgentRiyaApp:

def _init_(self, root):

    self.root = root

    self.root.title(WINDOW_TITLE)

    self.root.geometry("1100x640")

    self.root.minsize(980, 540)



    # Theme colors

    self.bg_top = "#0b1220"

    self.bg_bottom = "#071021"

    self.panel = "#0f1724"

    self.accent = "#6dd3ff"

    self.fg = "#e6eef8"

    self.muted = "#9aa7b2"



    # load tasks

    self.tasks = load_tasks()



    # Build UI

    self._build_ui()



    # Voice engine

    try:

        self.voice = VoiceEngine(self.on_speech_recognized)

    except Exception:

        self.voice = None

        self._append_message(ASSISTANT_NAME, "Microphone not available. Voice features disabled.")



    # greet

    self._append_message(ASSISTANT_NAME, INITIAL_GREETING)

    if self.voice:

        self.voice.speak(INITIAL_GREETING)

        self.voice.start_listening()

        self._set_listening(True)



# -------------------- UI --------------------

def _build_ui(self):

    self._create_gradient_bg()



    main = tk.Frame(self.root, bg=self.panel)

    main.place(relx=0.03, rely=0.03, relwidth=0.94, relheight=0.94)



    # Title bar

    title_frame = tk.Frame(main, bg=self.panel)

    title_frame.place(relx=0.01, rely=0.01, relwidth=0.98, relheight=0.08)

    title_lbl = tk.Label(title_frame, text=WINDOW_TITLE, bg=self.panel, fg=self.accent,

                         font=("Segoe UI", 18, 'bold'))

    title_lbl.pack(anchor='w', padx=12, pady=6)



    # Listening indicator on title bar (pulsing dot)

    self.listen_canvas = tk.Canvas(title_frame, width=22, height=22, bg=self.panel, highlightthickness=0)

    self.listen_canvas.pack(anchor='e', padx=12)

    self._listening_dot = self.listen_canvas.create_oval(3, 3, 19, 19, fill=self.accent)

    self._listening_pulse = 0

    self._listening_active = False

    self._animate_listening()



    # Left: conversation (rounded panel)

    left = tk.Frame(main, bg=self.panel)

    left.place(relx=0.01, rely=0.11, relwidth=0.66, relheight=0.86)



    conv_header = tk.Label(left, text="Agent Riya 9.0", bg=self.panel, fg=self.fg, font=("Segoe UI", 13, 'bold'))

    conv_header.pack(anchor='nw', padx=14, pady=(12,6))



    conv_container = tk.Frame(left, bg=self.bg_bottom, bd=0)

    conv_container.pack(fill='both', expand=True, padx=12, pady=(4,12))



    self.conv_canvas = tk.Canvas(conv_container, bg=self.bg_bottom, bd=0, highlightthickness=0)

    self.conv_scroll = ttk.Scrollbar(conv_container, orient='vertical', command=self.conv_canvas.yview)

    self.conv_frame = tk.Frame(self.conv_canvas, bg=self.bg_bottom)



    self.conv_frame.bind("<Configure>", lambda e: self.conv_canvas.configure(scrollregion=self.conv_canvas.bbox("all")))

    self.conv_canvas.create_window((0, 0), window=self.conv_frame, anchor='nw')

    self.conv_canvas.configure(yscrollcommand=self.conv_scroll.set)



    self.conv_canvas.pack(side='left', fill='both', expand=True)

    self.conv_scroll.pack(side='right', fill='y')



    # Right: To-do list (rounded panel)

    right = tk.Frame(main, bg=self.panel)

    right.place(relx=0.69, rely=0.11, relwidth=0.30, relheight=0.86)



    t_header = tk.Label(right, text="To-Do Task Management", bg=self.panel, fg=self.fg, font=("Segoe UI", 13, 'bold'))

    t_header.pack(anchor='nw', padx=12, pady=(12,6))



    todo_container = tk.Frame(right, bg=self.bg_bottom)

    todo_container.pack(fill='both', expand=True, padx=12, pady=(4,12))



    self.task_listbox = tk.Listbox(todo_container, bg=self.bg_bottom, fg=self.fg, bd=0, highlightthickness=0,

                                  font=("Segoe UI", 11), activestyle='none')

    self.task_listbox.pack(fill='both', expand=True, side='left')

    self.task_scroll = ttk.Scrollbar(todo_container, orient='vertical', command=self.task_listbox.yview)

    self.task_listbox.configure(yscrollcommand=self.task_scroll.set)

    self.task_scroll.pack(side='right', fill='y')



    self._refresh_task_list()



    footer = tk.Label(self.root, text="Voice-first — try: 'open youtube', 'add task buy milk', 'what is a computer'",

                      bg=self.bg_bottom, fg=self.muted, font=("Segoe UI", 9))

    footer.place(relx=0.03, rely=0.97, anchor='sw')



def _create_gradient_bg(self):

    w, h = 1200, 800

    img = Image.new('RGB', (w, h), color=self.bg_top)

    draw = ImageDraw.Draw(img)

    rgb1 = hex_to_rgb(self.bg_top)

    rgb2 = hex_to_rgb(self.bg_bottom)

    for i in range(h):

        t = i / h

        r = int(rgb1[0] * (1 - t) + rgb2[0] * t)

        g = int(rgb1[1] * (1 - t) + rgb2[1] * t)

        b = int(rgb1[2] * (1 - t) + rgb2[2] * t)

        draw.line([(0, i), (w, i)], fill=(r, g, b))

    img = img.filter(ImageFilter.GaussianBlur(6))

    self.bg_img = ImageTk.PhotoImage(img.resize((1400, 900), Image.LANCZOS))

    bg_label = tk.Label(self.root, image=self.bg_img)

    bg_label.place(x=0, y=0, relwidth=1, relheight=1)



# -------------------- Conversation helpers (message bubbles) --------------------

def _append_message(self, sender, message):

    bubble = tk.Frame(self.conv_frame, bg=self.bg_bottom)

    if sender == 'You':

        b = tk.Label(bubble, text=message, bg=self.accent, fg=self.bg_bottom, justify='left', wraplength=420,

                     font=("Segoe UI", 10), padx=10, pady=8)

        b.pack(anchor='e')

        bubble.pack(fill='x', anchor='e', pady=6, padx=(60, 10))

    else:

        b = tk.Label(bubble, text=message, bg="#0e1b29", fg=self.fg, justify='left', wraplength=420,

                     font=("Segoe UI", 10), padx=10, pady=8)

        b.pack(anchor='w')

        s = tk.Label(bubble, text=sender, bg=self.bg_bottom, fg=self.muted, font=("Segoe UI", 8))

        s.pack(anchor='w', pady=(4,0))

        bubble.pack(fill='x', anchor='w', pady=6, padx=(10, 60))



    self.conv_canvas.update_idletasks()

    self.conv_canvas.yview_moveto(1.0)



# -------------------- Task management --------------------

def _refresh_task_list(self):

    self.task_listbox.delete(0, 'end')

    for i, t in enumerate(self.tasks, 1):

        text = t.get('text')

        if t.get('done'):

            display = f"{i}. ✓ {text}"

        else:

            display = f"{i}. {text}"

        self.task_listbox.insert('end', display)



def add_task(self, text):

    text = text.strip()

    if not text:

        return False

    self.tasks.append({"text": text, "done": False})

    save_tasks(self.tasks)

    self._refresh_task_list()

    return True



def remove_task(self, identifier):

    removed = None

    try:

        idx = int(identifier) - 1

        if 0 <= idx < len(self.tasks):

            removed = self.tasks.pop(idx)

    except Exception:

        for i, t in enumerate(self.tasks):

            if identifier.lower() in t['text'].lower():

                removed = self.tasks.pop(i)

                break

    if removed:

        save_tasks(self.tasks)

        self._refresh_task_list()

        return True, removed

    return False, None



def complete_task(self, identifier):

    completed = None

    try:

        idx = int(identifier) - 1

        if 0 <= idx < len(self.tasks):

            self.tasks[idx]['done'] = True

            completed = self.tasks[idx]

    except Exception:

        for t in self.tasks:

            if identifier.lower() in t['text'].lower():

                t['done'] = True

                completed = t

                break

    if completed:

        save_tasks(self.tasks)

        self._refresh_task_list()

        return True, completed

    return False, None



def clear_all_tasks(self):

    self.tasks = []

    save_tasks(self.tasks)

    self._refresh_task_list()



# -------------------- Listening indicator --------------------

def _animate_listening(self):

    if self._listening_active:

        self._listening_pulse = (self._listening_pulse + 1) % 30

        scale = 1 + (self._listening_pulse / 90)

        x0, y0, x1, y1 = 3, 3, 19, 19

        cx = (x0 + x1) / 2

        cy = (y0 + y1) / 2

        r = 8 * scale

        self.listen_canvas.coords(self._listening_dot, cx - r/2, cy - r/2, cx + r/2, cy + r/2)

        self.listen_canvas.itemconfig(self._listening_dot, fill=self.accent)

    else:

        self.listen_canvas.coords(self._listening_dot, 3, 3, 19, 19)

        self.listen_canvas.itemconfig(self._listening_dot, fill="#4b5870")

    self.root.after(80, self._animate_listening)



def _set_listening(self, val: bool):

    self._listening_active = val



# -------------------- Command processing --------------------

def on_speech_recognized(self, text):

    user_text = text.strip()

    print("Recognized:", user_text)

    self._append_message('You', user_text)

    threading.Thread(target=self._process_command, args=(user_text,), daemon=True).start()



def _process_command(self, text):

    t = text.lower().strip()



    # exit command (highest priority)

    if any(x in t for x in ('exit', 'quit', 'bye')):

        resp = 'have a good day'

        self._append_message(ASSISTANT_NAME, resp)

        if self.voice:

            self.voice.speak(resp)

        # schedule GUI close on main thread after a delay to allow TTS to start

        try:

            self.root.after(1400, lambda: self._safe_close())

        except Exception:

            pass

        return



    # important commands

    if t.startswith('open youtube') or t == 'youtube':

        resp = 'Opening YouTube.'

        self._reply_and_open(resp, 'https://www.youtube.com')

        return

    if t.startswith('open google') or t == 'google':

        resp = 'Opening Google.'

        self._reply_and_open(resp, 'https://www.google.com')

        return

    if t.startswith('open gmail') or t == 'gmail':

        resp = 'Opening Gmail.'

        self._reply_and_open(resp, 'https://mail.google.com')

        return

    if 'calculator' in t or 'open calc' in t or t == 'open calculator':

        resp = 'Opening calculator.'

        self._append_message(ASSISTANT_NAME, resp)

        if self.voice:

            self.voice.speak(resp)

        try:

            subprocess.Popen('calc.exe')

        except Exception as e:

            print('Failed to open calculator:', e)

        return



    # tasks

    if t.startswith('add task'):

        task_text = text[len('add task'):].strip()

        if not task_text:

            resp = "I didn't hear the task description. Say: add task followed by the task name."

            self._append_message(ASSISTANT_NAME, resp)

            if self.voice:

                self.voice.speak(resp)

            return

        ok = self.add_task(task_text)

        resp = f'Added task: {task_text}' if ok else "Couldn't add the task."

        self._append_message(ASSISTANT_NAME, resp)

        if self.voice:

            self.voice.speak(resp)

        return



    if t.startswith('remove task'):

        identifier = text[len('remove task'):].strip()

        if not identifier:

            resp = 'Please say the task number or the task text to remove.'

            self._append_message(ASSISTANT_NAME, resp)

            if self.voice:

                self.voice.speak(resp)

            return

        ok, removed = self.remove_task(identifier)

        resp = f"Removed task: {removed['text']}" if ok else "Couldn't find that task to remove."

        self._append_message(ASSISTANT_NAME, resp)

        if self.voice:

            self.voice.speak(resp)

        return



    if t.startswith('task completed') or t.startswith('complete task') or t.startswith('completed task'):

        parts = text.split(maxsplit=2)

        identifier = text.split(' ', 2)[-1] if len(parts) >= 3 else ''

        if not identifier:

            resp = 'Please say the task number or text that is completed.'

            self._append_message(ASSISTANT_NAME, resp)

            if self.voice:

                self.voice.speak(resp)

            return

        ok, completed = self.complete_task(identifier)

        resp = f"Marked as completed: {completed['text']}" if ok else "Couldn't find that task to mark completed."

        self._append_message(ASSISTANT_NAME, resp)

        if self.voice:

            self.voice.speak(resp)

        return



    if t.startswith('clear all tasks') or t == 'clear tasks':

        self.clear_all_tasks()

        resp = 'All tasks cleared.'

        self._append_message(ASSISTANT_NAME, resp)

        if self.voice:

            self.voice.speak(resp)

        return



    # info commands

    for prefix in ('what is', 'explain', 'define'):

        if t.startswith(prefix):

            query = text[len(prefix):].strip()

            if not query:

                resp = 'Please say what you want me to explain or define.'

                self._append_message(ASSISTANT_NAME, resp)

                if self.voice:

                    self.voice.speak(resp)

                return

            try:

                summary = wikipedia.summary(query, sentences=2, auto_suggest=True, redirect=True)

                resp = summary

                self._append_message(ASSISTANT_NAME, resp)

                if self.voice:

                    self.voice.speak(resp)

                return

            except Exception:

                resp = f"I couldn't fetch a concise explanation. Searching the web for {query}."

                self._append_message(ASSISTANT_NAME, resp)

                if self.voice:

                    self.voice.speak(resp)

                webbrowser.open(f'https://www.google.com/search?q={urlquote(query)}')

                return



    # fallback

    resp = "Sorry, I didn't understand that."

    self._append_message(ASSISTANT_NAME, resp)

    if self.voice:

        self.voice.speak(resp)

    try:

        webbrowser.open(f'https://www.google.com/search?q={urlquote(text)}')

    except Exception:

        pass



def _reply_and_open(self, resp, url):

    self._append_message(ASSISTANT_NAME, resp)

    if self.voice:

        self.voice.speak(resp)

    webbrowser.open(url)



def _safe_close(self):

    # stop listening first

    try:

        if getattr(self, 'voice', None):

            self.voice.stop_listening()

    except Exception:

        pass

    try:

        self.root.quit()

        self.root.destroy()

    except Exception:

        pass

-------------------- Run --------------------

def main():

root = tk.Tk()

app = AgentRiyaApp(root)

root.protocol('WM_DELETE_WINDOW', lambda: (app._safe_close()))

root.mainloop()

if name == 'main':

main()